import json
from copy import deepcopy

def remove(machine: json) -> json:
    isPDA = False
    try:
        machine["state"]
        isPDA = True
    except KeyError:
        pass
    start = machine["start"]
    accepts = machine["accepts"]
    mach = machine["machine"]
    accessed = [start]
    new = {}
    new["start"] = start
    new["accepts"] = []
    new["machine"] = deepcopy(mach)

    for m in mach:
        for symbol in mach[m]:
            goto = mach[m][symbol]
            for to in goto:
                if isPDA:
                    accessed.append(to["goto"])
                else:
                    accessed.append(to)

    for m in mach:
        if m not in accessed:
            print("Removing",m)
            del new["machine"][m]

    for accept in accepts:
        if accept in accessed:
            new["accepts"].append(accept)
    new["accepts"].sort()

    f = open("output.json", 'a') #Append to the end
    new = json.dumps(new, indent=4, ensure_ascii=False)
    f.write(new+"\n")
    f.close()
    print("Done.")
    return new