import json
from info import get_language, get_states
from copy import deepcopy

def neat_trick(m1: json, m2: json) -> json:
    '''
    aka, combining two DFAs into another DFA.
    '''
    lang1 = get_language(m1)
    states1 = get_states(m1)
    lang2 = get_language(m2)
    states2 = get_states(m2)

    start1 = m1["start"]
    accepts1 = m1["accepts"]
    machine1 = m1["machine"]
    start2 = m2["start"]
    accepts2 = m2["accepts"]
    machine2 = m2["machine"]
    
    new = {}
    new["start"] = f"{start1}{start2}"
    new["accepts"] = []
    new["machine"] = {}

    states = []
    for state1 in states1:
        for state2 in states2:
            new_state = f"{state1}{state2}"
            new["machine"][new_state] = {}
            states.append((state1,state2))
            if state1 in accepts1 or state2 in accepts2:
                new["accepts"].append(new_state)
    
    lang = []
    for symbol in lang1:
        lang.append(symbol)
    for symbol in lang2:
        if symbol not in lang:
            lang.append(symbol)

    for state1, state2 in states:
        state = f"{state1}{state2}"
        for symbol in lang:
            new_state = [f"{machine1[state1][symbol][0]}{machine2[state2][symbol][0]}"]
            new["machine"][state][symbol] = new_state

    f = open("output.json", 'a') #Append to the end   
    new["accepts"].sort()
    new = json.dumps(new, indent=4, ensure_ascii=False)
    f.write(new+"\n")
    f.close()
    print("Done.")
    return new
    
def combine_NFA(m1: json, m2: json) -> json:
    new = {}
    new["start"] = "q0"
    new["accepts"] = []
    new["machine"] = {}
    new["machine"]["q0"] = {}
    new["machine"]["q0"]["λ"] = ["m1"+m1["start"]]
    new["machine"]["q0"]["λ"].append("m2"+m2["start"])

    machine1 = deepcopy(m1["machine"])
    for state in m1["machine"]:
        new_state = "m1"+state
        machine1[new_state] = {}
        for symbol in m1["machine"][state]:
            machine1[new_state][symbol] = []
            for goto in m1["machine"][state][symbol]:
                machine1[new_state][symbol].append("m1"+goto)
        if state in m1["accepts"]:
            new["accepts"].append(new_state)

    machine2 = deepcopy(m2["machine"])
    for state in m2["machine"]:
        new_state = "m2"+state
        machine2[new_state] = {}
        for symbol in m2["machine"][state]:
            machine2[new_state][symbol] = []
            for goto in m2["machine"][state][symbol]:
                machine1[new_state][symbol].append("m2"+goto)
        if state in m2["accepts"]:
            new["accepts"].append(new_state)

    new["accepts"].sort()

    new["machine"].update(machine1)
    new["machine"].update(machine2)
    f = open("output.json", 'a') #Append to the end
    new = json.dumps(new, indent=4, ensure_ascii=False)
    f.write(new+"\n")
    f.close()
    print("Done.")
    return new