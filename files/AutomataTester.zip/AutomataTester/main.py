import json
import itertools

from info import get_states, get_language, get_stack_language
from traverse import traverse_finite, traverse_pushdown
from convert import convert_NFA, remove_lambda
from combine import neat_trick, combine_NFA
from remove import remove
from regex import regex

choicestr = '''Select an action:
0: Quit.
1: Test the language of a FA/PDA.
2: Print information on a FA/PDA.
3: Convert NFA to DFA.
4: Convert NFAλ to NFA.
5: Combine two DFAs with the same language.
6: Combine two FAs.
7: Remove unused states from a machine.
8: Convert FA to regex.
9: Convert PDA to CFG.
'''

def verify() -> str:
    automata = None
    while not automata:
        automata = input("Select automata: ").upper()
        try:
            data[automata]
        except KeyError:
            print("That automata is not in the file.")
            automata = None

    return automata

def test(automata: json):
    letters = None
    while not letters:
        try:
            letters = int(input("Select a maximum length for the language: "))
        except ValueError:
            letters = None

    is_PDA = False
    try:
        automata["stack"]
        is_PDA = True
    except KeyError:
        pass

    if is_PDA:
        func = traverse_pushdown
    else:
        func = traverse_finite

    results = {}
    results["ε"] = func(automata, "")
    for i in range(letters):
        for string in itertools.product(get_language(automata), repeat=i+1):
            s = "".join(string)
            results[s] = func(automata, s)
            
    for key, val in results.items():
        if val:
            print(key)

def print_info(automata: json):
    print("Language (Σ):", get_language(automata))
    print("States (Q):", get_states(automata))
    print("Start state (q0):", automata["start"])
    print("Accepts (F):", automata["accepts"])
    try:
        print("Stack start (z0):", automata["stack"])
        print("Stack Language (ᴦ):", get_stack_language(automata))
    except:
        pass
    print("Transition (δ):")
    for state in automata["machine"]:
        print(f"\t{state}: {automata["machine"][state]}")

if __name__ == "__main__":
    output = open("output.json", 'a') #Append to the end

    file = ""
    while not file:
        try:
            file = open("jsons/"+input("Read file: "))
            data = json.load(file)
        except FileNotFoundError:
            print("File does not exist!")
        except json.JSONDecodeError:
            print("File is not a json file!")
            file = ""

    choice = None
    while choice != 0:
        try:
            choice = int(input(choicestr))
        except ValueError:
            print("Invalid input, exiting program.")
            choice = 0

        if choice == 0:
            print("bye bye")
        else:
            func = None
            func2 = None
            match choice:
                case 1:
                    func = test
                case 2:
                    func = print_info
                case 3:
                    func = convert_NFA
                case 4:
                    func = remove_lambda
                case 5:
                    func2 = neat_trick
                case 6:
                    func2 = combine_NFA
                case 7:
                    func = remove
                case 8:
                    func = regex
                case 9:
                    pass
                case _:
                    print("Choice does not correspond to an action.")
                    continue

            if func:
                result = func(data[verify()])
            elif func2:
                result = func2(data[verify()],data[verify()])
            
            if result:
                new = json.dumps(result, indent=4, ensure_ascii=False)
                output.write(new+"\n")
                
    file.close()
    output.close()