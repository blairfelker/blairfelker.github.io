import json

def get_states(automata: json):
    states = []
    for state in automata["machine"]:
        states.append(state)
    return states

def get_language(automata: json):
    language = []
    machine = automata["machine"]
    for state in machine:
        for symbol in machine[state]:
            if symbol not in language and symbol != "λ":
                language.append(symbol)
    return language

def get_stack_language(automata: json):
    stack_language = []
    machine = automata["machine"]
    for state in machine:
        for symbol in machine[state]:
            for i in range(len(machine[state][symbol])):
                transition = machine[state][symbol][i]
                pop = transition["pop"]
                place = transition["push"]
                
                if pop not in stack_language and pop != "λ":
                    stack_language.append(pop)
                if place not in stack_language and place != "λ":
                    stack_language.append(place)
            if symbol not in stack_language and symbol != "λ":
                stack_language.append(symbol)
    return stack_language