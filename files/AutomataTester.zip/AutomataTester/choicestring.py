choicestr = '''Select an action:
    0: Quit.
    1: Test the language of a FA/PDA.
    2: Print information on a FA/PDA.
    3: Convert NFA to DFA.
    4: Combine two DFAs with the same language.
    5: Combine two FAs.
    6: Remove unused states from a machine.
    7: Convert FA to regex.
    8: Convert PDA to CFG.
'''