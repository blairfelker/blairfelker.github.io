import json
from copy import copy

class nodeFA:
    '''
    s- the state the node is in
    l- the letter the node will use
    p- the current position in the entire string
    '''
    def __init__(self, state: str, letter: str, position: int) -> None:
        self.s = state
        self.l = letter
        self.p = position

def exhaust_finite(pos: str, accepts: list[str], machine: json) -> bool:
    '''
    Exhausts the machine for any lambda transitions that might satisfy the accepting states.
    Usually only called if the string passed is ε, or the end of the string was reached.
    '''
    queue = [pos]
    while queue:
        curr = queue.pop(0)
        if curr in accepts:
            return True
        if "λ" in machine[curr]:
            for state in machine[curr]["λ"]:
                queue.append(state)
    return False

def traverse_finite(m: json, string: str) -> bool:
    '''
    Traverses a DFA or NDFA.
    Returns whether the string passed in is accepted or not.
    Acts like a breadth-first-search, where moves are appened onto a queue until ANY solution is found.
    '''

    start = m["start"]
    accepts = m["accepts"]
    machine = m["machine"]
    if string == "":
        return exhaust_finite(start,accepts,machine)
    
    queue = [nodeFA(start, string[0], 0)]
    max = len(string) - 1
    
    while queue:
        curr = queue.pop(0)
        if "λ" in machine[curr.s]:
            for state in machine[curr.s]["λ"]:
                queue.append(nodeFA(state, string[curr.p], curr.p))

        try:
            if curr.p == max:
                for state in machine[curr.s][curr.l]:
                    if exhaust_finite(state,accepts,machine):
                        return True
                    
            else: #Don't need to test for λs here. It's based off of the string.
                for state in machine[curr.s][curr.l]:
                    queue.append(nodeFA(state, string[curr.p+1], curr.p+1))
        except KeyError:
            continue #Go to next state in queue.

    return False

class nodePDA:
    '''
    s- the state the node is in
    l- the letter the node will use
    p- the current position in the entire string
    f- the frontier (stack) associated with the actions
    '''
    def __init__(self, state: str, letter: str, position: int, frontier: list[str]) -> None:
        self.s = state
        self.l = letter
        self.p = position
        self.f = frontier

class exhaust:
    '''
    s- the state the node is in
    f- the frontier (stack) associated with the actions

    this class is used during the exhaust 
    '''
    def __init__(self, state, frontier) -> None:
        self.s = state
        self.f = frontier

def edit_stack(stack: list[str], pop: str, push: str) -> list[str]:
    '''
    Edits the stack. If the pop arg is the last in the stack, then it is popped, push is appended
    '''
    stack_copy = copy(stack)

    if pop == stack_copy[-1]:
        stack_copy.pop()
    elif pop != "λ":
        return
    
    if push != "λ":
        stack_copy.append(push)

    return stack_copy

def exhaust_pushdown(pos: str, accepts: list[str], machine: json, stack:list[str]) -> bool:
    '''
    Exhausts the machine for any lambda transitions that might satisfy the accepting states
    Usually only called if the string passed is ε, or the end of the string was reached.
    '''
    queue = [exhaust(pos,stack)]
    while queue:
        curr = queue.pop(0)
        if curr.s in accepts and not curr.f:
            return True
        if not curr.f or len(curr.f) == 50:
            continue
        if "λ" in machine[curr.s]:
            for state in machine[curr.s]["λ"]:
                new_stack = edit_stack(curr.f, state["pop"], state["push"])
                if new_stack != None:
                    queue.append(exhaust(state["goto"], new_stack))

def traverse_pushdown(m: json, string: str) -> bool:
    '''
    Traverses a PDA.
    Returns whether the string passed in is accepted or not.
    Acts like a breadth-first-search, where moves are appended onto a queue until ANY solution is found.
    '''
    start = m["start"]
    stack_begin = m["stack"]
    accepts = m["accepts"]
    machine = m["machine"]

    stack = [stack_begin]
    if string == "":
        return exhaust_pushdown(start, accepts, machine, stack)
    queue = [nodePDA(start, string[0], 0, stack)]
    max = len(string) - 1
    while queue:
        curr = queue.pop(0)
        if not curr.f:
            continue
        if "λ" in machine[curr.s]:
            for state in machine[curr.s]["λ"]:
                new_stack = edit_stack(curr.f, state["pop"], state["push"])
                if new_stack != None:
                    queue.append(nodePDA(state["goto"], curr.l, curr.p, new_stack))
        
        try:
            if curr.p == max:
                for state in machine[curr.s][curr.l]:
                    new_stack = edit_stack(curr.f, state["pop"], state["push"])
                    if new_stack != None:
                        if exhaust_pushdown(state["goto"],accepts,machine,new_stack):
                            return True
            else:
                for state in machine[curr.s][curr.l]:
                    new_stack = edit_stack(curr.f, state["pop"], state["push"])
                    if new_stack != None:
                        queue.append(nodePDA(state["goto"], string[curr.p+1], curr.p+1, new_stack))
        except KeyError:
            continue
    return False