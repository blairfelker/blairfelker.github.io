import json
from info import get_states, get_language
from copy import copy, deepcopy

def remove_lambda(data: json) -> json:
    '''
    Takes in an automata and returns an equivalent automata with no lambda transitions.
    '''
    start = data["start"]
    accepts = data["accepts"]
    machine = data["machine"]

    new = {}
    new["start"] = start
    new["accepts"] = copy(accepts)
    new["machine"] = deepcopy(machine)

    for state in machine:
        queue = [state]
        while queue:
            curr = queue.pop(0)
            if curr in accepts and state not in new["accepts"]:
                new["accepts"].append(state)
            if "λ" in machine[curr]:
                for s in machine[curr]["λ"]:
                    queue.append(s)

    for state in machine:
        curr_state = data["machine"][state]
        for symbol in curr_state:
            if symbol == "λ":
                for next_state in curr_state["λ"]:
                    new_state = new["machine"][state]
                    for next_symbol in data["machine"][next_state]:
                        try:
                            if next_state not in new_state[next_symbol]:
                                new_state[next_symbol].append(next_state)
                        except KeyError:
                            new_state[next_symbol] = new["machine"][next_state][next_symbol]
                    try:
                        del new_state["λ"]
                    except KeyError: # Excepts if lambda has already been deleted.
                        continue

    return new

def convert_NFA(data: json) -> None:
    '''
    Takes in an automata, calls remove_lambda, then outputs an automata that is a DFA to output.json.
    '''
    data = remove_lambda(data)
    start = data["start"]
    accepts = data["accepts"]
    machine = data["machine"]
    lang = get_language(data)
    old_states = get_states(data)

    new = {}
    new["start"] = start
    new["accepts"] = copy(accepts)
    new["machine"] = deepcopy(machine)
    has_dead = False
    new_states_dict = {}
    new_states = []

    for state in machine:
        curr_state = data["machine"][state]
        for symbol in lang:
            try:
                curr_state[symbol]
            except KeyError:
                new["machine"][state][symbol] = ["Ø"]
                has_dead = True
            else:
                if len(curr_state[symbol]) > 1:
                    new_state = []
                    new_accept = False

                    for s in curr_state[symbol]:
                        if s not in new_state:
                            new_state.append(s)
                        if s in accepts:
                            new_accept = True

                    new_state.sort()
                    new_state_name = "".join(new_state)
                    if new_state_name not in new_states:
                        if new_accept:
                            new["accepts"].append(new_state_name)

                        new["machine"][new_state_name] = {}
                        new_states_dict[new_state_name] = curr_state[symbol]
                        new_states.append(new_state_name)
                        new["machine"][state][symbol] = [new_state_name]

    for state in new_states:
        curr_state = new["machine"][state]

        for symbol in lang:
            new_state = []
            new_accept = False
            for old in new_states_dict[state]:
                for o in machine[old][symbol]:
                    if o not in new_state:
                        new_state.append(o)
                    if o in accepts:
                        new_accept = True

            new_state.sort()
            new_state_name = "".join(new_state)
            curr_state[symbol] = [new_state]
            if new_state_name not in new_states and new_state_name not in old_states:
                if new_accept:
                    new["accepts"].append(new_state_name)

                new["machine"][new_state_name] = {}
                new_states_dict[new_state_name] = new_state
                new_states.append(new_state_name)

            new["machine"][state][symbol] = [new_state_name]

    if has_dead:
        new["machine"]["Ø"] = {}
        for symbol in lang:
            new["machine"]["Ø"][symbol] = ["Ø"]
            
    new["accepts"].sort()

    f = open("output.json", 'a') #Append to the end
    new = json.dumps(new, indent=4, ensure_ascii=False)
    f.write(new+"\n")
    f.close()
    print("Done.")
    return new
